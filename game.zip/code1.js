gdjs.startCode = {};
gdjs.startCode.GDGreenButtonObjects1= [];
gdjs.startCode.GDGreenButtonObjects2= [];
gdjs.startCode.GDRedButtonObjects1= [];
gdjs.startCode.GDRedButtonObjects2= [];
gdjs.startCode.GDNewTextObjects1= [];
gdjs.startCode.GDNewTextObjects2= [];


gdjs.startCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("GreenButton"), gdjs.startCode.GDGreenButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.startCode.GDGreenButtonObjects1.length;i<l;++i) {
    if ( gdjs.startCode.GDGreenButtonObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.startCode.GDGreenButtonObjects1[k] = gdjs.startCode.GDGreenButtonObjects1[i];
        ++k;
    }
}
gdjs.startCode.GDGreenButtonObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "game", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("RedButton"), gdjs.startCode.GDRedButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.startCode.GDRedButtonObjects1.length;i<l;++i) {
    if ( gdjs.startCode.GDRedButtonObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.startCode.GDRedButtonObjects1[k] = gdjs.startCode.GDRedButtonObjects1[i];
        ++k;
    }
}
gdjs.startCode.GDRedButtonObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.stopGame(runtimeScene);
}}

}


};

gdjs.startCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.startCode.GDGreenButtonObjects1.length = 0;
gdjs.startCode.GDGreenButtonObjects2.length = 0;
gdjs.startCode.GDRedButtonObjects1.length = 0;
gdjs.startCode.GDRedButtonObjects2.length = 0;
gdjs.startCode.GDNewTextObjects1.length = 0;
gdjs.startCode.GDNewTextObjects2.length = 0;

gdjs.startCode.eventsList0(runtimeScene);

return;

}

gdjs['startCode'] = gdjs.startCode;
