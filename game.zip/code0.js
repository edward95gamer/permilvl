gdjs.gameCode = {};
gdjs.gameCode.GDplayerObjects1= [];
gdjs.gameCode.GDplayerObjects2= [];
gdjs.gameCode.GDplayerObjects3= [];
gdjs.gameCode.GDFlatDarkJoystickObjects1= [];
gdjs.gameCode.GDFlatDarkJoystickObjects2= [];
gdjs.gameCode.GDFlatDarkJoystickObjects3= [];
gdjs.gameCode.GDPineObjects1= [];
gdjs.gameCode.GDPineObjects2= [];
gdjs.gameCode.GDPineObjects3= [];


gdjs.gameCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.gameCode.GDplayerObjects2);
{for(var i = 0, len = gdjs.gameCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.gameCode.GDplayerObjects2[i].getBehavior("TopDownMovement").simulateLeftKey();
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.gameCode.GDplayerObjects2);
{for(var i = 0, len = gdjs.gameCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.gameCode.GDplayerObjects2[i].getBehavior("TopDownMovement").simulateRightKey();
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "s");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.gameCode.GDplayerObjects2);
{for(var i = 0, len = gdjs.gameCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.gameCode.GDplayerObjects2[i].getBehavior("TopDownMovement").simulateDownKey();
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "w");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.gameCode.GDplayerObjects1);
{for(var i = 0, len = gdjs.gameCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDplayerObjects1[i].getBehavior("TopDownMovement").simulateUpKey();
}
}}

}


};gdjs.gameCode.eventsList1 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.systemInfo.hasTouchScreen(runtimeScene));
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("FlatDarkJoystick"), gdjs.gameCode.GDFlatDarkJoystickObjects1);
{for(var i = 0, len = gdjs.gameCode.GDFlatDarkJoystickObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDFlatDarkJoystickObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDplayerObjects1Objects = Hashtable.newFrom({"player": gdjs.gameCode.GDplayerObjects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDPineObjects1Objects = Hashtable.newFrom({"Pine": gdjs.gameCode.GDPineObjects1});
gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDPineObjects1Objects = Hashtable.newFrom({"Pine": gdjs.gameCode.GDPineObjects1});
gdjs.gameCode.eventsList2 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Pine"), gdjs.gameCode.GDPineObjects1);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.gameCode.GDplayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDplayerObjects1Objects, gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDPineObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.gameCode.GDPineObjects1 */
/* Reuse gdjs.gameCode.GDplayerObjects1 */
{for(var i = 0, len = gdjs.gameCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDplayerObjects1[i].separateFromObjectsList(gdjs.gameCode.mapOfGDgdjs_9546gameCode_9546GDPineObjects1Objects, false);
}
}}

}


};gdjs.gameCode.eventsList3 = function(runtimeScene) {

{


gdjs.gameCode.eventsList0(runtimeScene);
}


{


gdjs.gameCode.eventsList1(runtimeScene);
}


{


gdjs.gameCode.eventsList2(runtimeScene);
}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Journey of Hope.aac", true, 100, 1);
}}

}


};

gdjs.gameCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.gameCode.GDplayerObjects1.length = 0;
gdjs.gameCode.GDplayerObjects2.length = 0;
gdjs.gameCode.GDplayerObjects3.length = 0;
gdjs.gameCode.GDFlatDarkJoystickObjects1.length = 0;
gdjs.gameCode.GDFlatDarkJoystickObjects2.length = 0;
gdjs.gameCode.GDFlatDarkJoystickObjects3.length = 0;
gdjs.gameCode.GDPineObjects1.length = 0;
gdjs.gameCode.GDPineObjects2.length = 0;
gdjs.gameCode.GDPineObjects3.length = 0;

gdjs.gameCode.eventsList3(runtimeScene);

return;

}

gdjs['gameCode'] = gdjs.gameCode;
